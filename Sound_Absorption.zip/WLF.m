clc;
Tg=23.2+273; %Glass Transition Temperature ( In Kelvin )
T=30+273;  %Working Temperature ( In Kelvin )
C1=15.6; C2=32.6; %Polyurethane Elastomer Constants
FTg=1;   %DMTA Frequency 1/s
T-Tg

F=FTg/(10^ (  -C1*(T-Tg)/(C2+(T-Tg))  ) )