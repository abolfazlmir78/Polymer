clc;
D1=5; D2=10; D3=20 ;        % Enter Diameters D1<D2<D3
V1=.30; V2=.40; V3=1-V2-V1; %Enter Volume Fraction
%1

[Phi_si Phi_is]=phi_pack (D2/D1);
[Phi_sl Phi_ls]=phi_pack (D3/D1);
Phi_m_s=0.639*V1+Phi_si*V2+Phi_sl*V3;

%2

[Phi_il Phi_li]=phi_pack (D3/D2);
Phi_m_i=Phi_is*V1+0.639*V2+Phi_il*V3;

%3

Phi_m_l=Phi_ls*V1+Phi_li*V2+0.639*V3;
P= [Phi_m_s Phi_m_i Phi_m_l];
min(P)