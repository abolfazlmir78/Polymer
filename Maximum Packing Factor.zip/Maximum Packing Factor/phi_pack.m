function [phi_sl,phi_ls] = phi_pack(x)
if ( x<50 ) %PHI_SL
    phi_sl = 0.0001*x^3 - 0.0054*x^2 + 0.078*x + 0.5555;

else
    phi_sl = 0.950;
end

%%%

if ( x<50 ) %PHI_LS
   phi_ls = 0.00004*x^4 - 0.0017*x^3 + 0.0184*x^2 + 0.0179*x + 0.589;
else
   phi_ls = 1.52;
end
 