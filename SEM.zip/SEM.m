rgb=imread('2.jpg');
%rgb=rgb2gray(rgb); %Convert RGB Image to GreyScale
imshow(rgb);

%d = imdistline; %It is Necessary to Measure Minimum and Maximum Radius of
%Objects imdistline is a Handy Tool For Measuring Maximum and Minimum
%Radius
[centersBright, radiiBright] = imfindcircles(rgb,[9 20],'ObjectPolarity', ...
    'bright','Sensitivity',0.95);


%%%Scale
Line=41.74; % 1 micrometer is equal to 40
sc=1/Line;
Radius=radiiBright*sc;

h = viscircles(centersBright,radiiBright);
%%Statistic

Varience=var(Radius);
CV=Varience^(1/2)/mean(Radius)